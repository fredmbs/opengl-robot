/*
 * Light.cpp
 *
 *  Created on: 13/06/2012
 *      Author: Frederico Sampaio
 */

#include "Light.h"

Light::Light() {
	// TODO Auto-generated constructor stub

}

Light::~Light() {
	// TODO Auto-generated destructor stub
}


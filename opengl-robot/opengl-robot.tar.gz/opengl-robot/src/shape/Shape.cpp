/*
 * VisualForm.cpp
 *
 *  Created on: 11/06/2012
 *      Author: Frederico Sampaio
 */

#include "Shape.h"

Shape::Shape()
{
}

Shape::~Shape() {
}


/*
 * Light.h
 *
 *  Created on: 13/06/2012
 *      Author: Frederico Sampaio
 */

#ifndef LIGHT_H_
#define LIGHT_H_

class Light {
public:
	Light();
	virtual ~Light();
};

#endif /* LIGHT_H_ */
